
/*
 * Author: Ken Reid
 */
import java.io.FileWriter;
import java.io.IOException;

public class Output {

	public void go(final String html) {
		try {
			final FileWriter myWriter = new FileWriter("data/publications.html");
			myWriter.write(html);
			myWriter.close();
		} catch (final IOException e) {
			e.printStackTrace();
		}
	}

}
