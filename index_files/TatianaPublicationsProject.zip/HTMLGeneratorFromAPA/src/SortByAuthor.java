/*
 * Author: Ken Reid
 */
import java.util.Comparator;

public class SortByAuthor implements Comparator {

	@Override
	public int compare(final Object o1, final Object o2) {
		// TODO Auto-generated method stub
		final String first = (String) o1;
		final String second = (String) o2;
		return first.compareTo(second);
	}

}
