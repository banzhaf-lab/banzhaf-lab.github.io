
/*
 * Author: Ken Reid
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Test {

	public static void main(final String[] args) {
		final Test test = new Test();
		test.go();
	}

	private void go() {
		// get input
		final Input input = new Input(
				"/Users/reidken1/eclipse-workspace/HTMLGeneratorFromAPA/data/Banzhaf_Publications.txt");
		final List<String> apa = input.getInput();
		// sort by year into buckets
		final Map<Integer, List<String>> apaByYear = this.sortApasByYear(apa);
		// create html
		final String html = this.createHTMLfromSortedApas(apaByYear);
		final Output output = new Output();
		output.go(html);
		System.out.println("Finished.");

	}

	private String createHTMLfromSortedApas(final Map<Integer, List<String>> apaByYear) {
		String output = "";
		for (int i = 2021; i > 2015; i--) {
			final List<String> apas = apaByYear.get(i);
			output = output + "\n<h3>" + i + "</h3>\n\t<ol>\n";
			for (final String apa : apas) {
				output = output + "\t\t<li>\n\t\t\t" + apa + "\n\t\t</li>\n";
			}
			output = output + "\t</ol>";
		}
		return output;
	}

	private Map<Integer, List<String>> sortApasByYear(final List<String> apa) {
		final Map<Integer, List<String>> apaByYear = new HashMap<Integer, List<String>>();
		for (final String s : apa) {

			// get the year from the current string by splitting the string into arrays
			// based on where the brackets are.
			int position = s.indexOf("(") + 1;
			int secondPosition = s.indexOf(")");
			if (secondPosition - position == 5) {
				secondPosition = secondPosition - 1;
			}
			String preIntegerization = s.substring(position, secondPosition);
			if (!Test.isNumeric(preIntegerization)) {
				position = s.indexOf("(", position + 1) + 1;
				secondPosition = s.indexOf(")", secondPosition + 1);
				if (secondPosition - position == 5) {
					secondPosition = secondPosition - 1;
				}
				preIntegerization = s.substring(position, secondPosition);
			}
			final int year = Integer.parseInt(preIntegerization);
			System.out.println(year);
			if (apaByYear.containsKey(year)) {
				apaByYear.get(year).add(s);
			} else {
				final List<String> list = new ArrayList<String>();
				list.add(s);
				apaByYear.put(year, new ArrayList<String>(list));
			}
		}
		this.sortApasByFirstAuthor(apaByYear);
		return apaByYear;

	}

	public static boolean isNumeric(final String str) {
		try {
			Integer.parseInt(str);
			return true;
		} catch (final NumberFormatException e) {
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	private void sortApasByFirstAuthor(final Map<Integer, List<String>> apaByYear) {
		for (final Entry<Integer, List<String>> e : apaByYear.entrySet()) {
			Collections.sort(e.getValue(), new SortByAuthor());
		}
	}
}
