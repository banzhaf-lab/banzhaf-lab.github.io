
/*
 * Author: Ken Reid
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Input {
	private File file;

	Input(final String path) {
		this.setFile(new File(path));

	}

	public File getFile() {
		return this.file;
	}

	public void setFile(final File file) {
		this.file = file;
	}

	public List<String> getInput() {
		final List<String> stringList = new ArrayList<String>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(this.file));
			String st;
			while ((st = br.readLine()) != null) {
				if (!st.equals("\n") && !st.equals("")) {
					stringList.add(st);
				}

			}
		} catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stringList;
	}
}
